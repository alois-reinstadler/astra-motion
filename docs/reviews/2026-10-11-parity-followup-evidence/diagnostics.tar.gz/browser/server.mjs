import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
const root = import.meta.dirname;
if (!process.env.PORT) throw new Error('Run under Portless for an allocated port.');
createServer(async (req, res) => {
  const name = new URL(req.url, 'http://local').pathname.slice(1) || 'index.html';
  if (!['index.html', 'cache.html', 'cache-probe.js', 'probe.js', 'baseline.js', 'style.css', 'provenance.json'].includes(name)) {
    res.writeHead(404).end(); return;
  }
  try {
    const content = await readFile(resolve(root, name));
    res.setHeader('Content-Type', name.endsWith('.js') ? 'text/javascript' : name.endsWith('.css') ? 'text/css' : name.endsWith('.json') ? 'application/json' : 'text/html');
    res.end(content);
  } catch { res.writeHead(500).end(); }
}).listen(Number(process.env.PORT), '127.0.0.1', () => console.log(`Diagnostic server ready: ${process.env.PORT}`));
