import base from "/home/node/.t3/worktrees/astra-motion/t3code-10ab3c8f/vitest.motion.config.ts";
export default {
 ...base, cacheDir: '/tmp/astra-projection-ownership/vite-cache',
 plugins: [...base.plugins, {name:'ownership-readonly-trace',enforce:'post',transform(code,id){
 if(id.endsWith('/src/lib/motion/layout.ts')) return code.replace('projection.mount(element);', `
projection.addEventListener('measure', () => console.log('REVIEW_MEASURE', JSON.stringify({id:element.getAttribute('data-shared-box'),snapshot:projection.snapshot,layout:projection.layout,path:projection.path.map(a=>({id:a.id,values:a.latestValues,css:a.instance?.style?.cssText,layout:a.layout,previousOffset:a.previousOffset}))})));
projection.addEventListener('didUpdate', (e) => console.log('REVIEW_UPDATE', JSON.stringify({id:element.getAttribute('data-shared-box'),e})));
projection.mount(element);`)+`
globalThis.__projectionReview = () => [...participants.values()].map(({element,projection:p})=>({id:element.getAttribute('data-shared-box'),style:element.style.cssText,rect:element.getBoundingClientRect().toJSON(),projection:{id:p.id,latestValues:p.latestValues,layout:p.layout,snapshot:p.snapshot,target:p.target,delta:p.projectionDelta,origin:p.targetLayout,resumeFrom:p.resumeFrom?.id,currentAnimation:!!p.currentAnimation,rootAnimationId:p.root.animationId,rootUpdating:p.root.isUpdating,path:p.path.map(a=>({tag:a.instance?.tagName,attrs:a.instance?.getAttribute?.('data-shared-parent'),id:a.id,values:a.latestValues,layout:a.layout,snapshot:a.snapshot,delta:a.projectionDelta,previousOffset:a.previousOffset}))}}));
`;
 if(id.endsWith('/src/lib/motion/projection-boundaries.ts')) return code.replace('restore = () => {', `restore = () => { if(this.id===14) console.log('REVIEW_RESTORE',JSON.stringify({saved:!!this.saved,css:this.element.style.cssText,stack:new Error().stack}));`).replace('resetTransform() {', `resetTransform() { console.log('REVIEW_RESET',JSON.stringify({id:this.id,saved:!!this.saved,values:this.latestValues,css:this.element.style.cssText,rootUpdating:this.root.isUpdating,rootId:this.root.animationId}));`).replace('resetSkewAndRotation() {',`resetSkewAndRotation() { console.log('REVIEW_SKEW',JSON.stringify({id:this.id,saved:!!this.saved,values:this.latestValues,css:this.element.style.cssText,rootUpdating:this.root.isUpdating,rootId:this.root.animationId}));`);
 if(id.endsWith('/presence-snapshot.svelte.spec.ts')) return code+`
it('review: two mounted roots share outer ownership without stale pop size', async () => {
 const a = render(Fixture,{transaction:true}); const b = render(Fixture,{transaction:true});
 await tick();
 const texts = [...document.querySelectorAll('[data-pop-resize-text]')];
 const original = getComputedStyle(texts[1]).width;
 let outer;
 updateLayout(() => {outer=currentPresenceSnapshot(); a.component.resize(240); b.component.toggle(); expect(currentPresenceSnapshot()).toBe(outer);});
 await tick();
 expect(currentPresenceSnapshot()).toBeUndefined();
 expect(getComputedStyle(texts[0]).position).not.toBe('absolute');
 expect(getComputedStyle(texts[1]).position).toBe('absolute');
 expect(getComputedStyle(texts[1]).width).toBe(original);
 await a.unmount(); await b.unmount();
});
`;
 if(id.endsWith('/upstream-shared-layout-expanded.svelte.spec.ts')) return code.replace('near(source.left, parent.left);', 'console.log("PROJECTION_REVIEW",scenario,JSON.stringify(globalThis.__projectionReview())); near(source.left, parent.left);');
 }}]
};
