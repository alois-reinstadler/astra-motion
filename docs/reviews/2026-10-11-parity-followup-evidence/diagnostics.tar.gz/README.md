# Isolated parity diagnostics

Source inspected: /home/node/.t3/worktrees/astra-motion/t3code-10ab3c8f at 14ae1cb plus the preserved ownership work. No production source changed.

Original scratch roots: /tmp/astra-auto-capture, /tmp/astra-presence-contract, /tmp/astra-projection-ownership, /tmp/astra-parity-root. Scripts retain these paths and depend on the original worktree dependencies. Generated bundles and node_modules are deliberately omitted. Restore the corresponding lane into its original scratch root and provide a node_modules symlink to the inspected worktree before rebuilding if replay is needed. Do not execute build scripts in the repository root.

Automatic: build.mjs/run.mjs measure normal and async Svelte ordering; committed-build.mjs creates control/committed/committed-seeded/seed-only variants; committed-run.mjs and seed-run.mjs measure geometry, then verify.mjs checks preserved positive and negative assertions.

Presence: react-probe.mjs, svelte-probe.mjs and selector-probe.mjs print actual browser outcomes. Run sequentially because they reuse one scratch root.

Projection: trace.config.mjs, sync-commit.config.mjs and cross-root.config.mjs are Vitest diagnostic configurations that transform loaded modules without editing source. Run from the inspected worktree with MOTION_BROWSER=chromium, pnpm exec vitest run --config <absolute-config> and the focused upstream-shared-layout-expanded/presence-snapshot files. -t layout-parent-translations selects the two-case history reproduction; --config selects the diagnostic configuration. Traces and focused logs preserve the exact outcomes.

Browser: index.html/cache.html/server.mjs are the primary-agent interactive harness. They require the provenance-pinned generated probe/baseline bundles or rebuilt seed-only bundle in the scratch directory. Start the server through Portless, which supplies PORT; no network configuration was changed. The standalone React-containing original bundle requires NODE_ENV supplied by the HTML harness.

These are diagnostic controls, not production fixes or a portable published-package test suite. rAF samples are not independently verified displayed frames.
