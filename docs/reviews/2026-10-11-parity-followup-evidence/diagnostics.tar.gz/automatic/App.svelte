<script>
  import Child from './Child.svelte';
  let columns = $state(3);
  let items = $state([0, 1, 2]);
  let open = $state(false);
  let resolve;
  let promise = new Promise(done => { resolve = done; });
  window.actions = {
    combined() { columns = 1; items = [2, 1, 0]; },
    siblingCombined() { open = true; items = [2, 1, 0]; },
    reverse() { items.reverse(); },
    splice() { items.splice(0, 1); },
    sibling() { open = !open; },
    await() { resolve(true); }
  };
</script>
{#if open}<div data-sibling style="height:70px">Sibling</div>{/if}
{#await promise}<div style="height:30px">Pending</div>{:then}<div style="height:100px">Ready</div>{/await}
<div data-grid style:display="grid" style:width="300px" style:grid-template-columns={`repeat(${columns},1fr)`}>
  <Child {items}/>
</div>
