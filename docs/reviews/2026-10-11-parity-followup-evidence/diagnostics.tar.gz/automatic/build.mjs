import { build } from 'vite';
import { svelte } from '@sveltejs/vite-plugin-svelte';
for (const async of [false, true]) {
  await build({ configFile: false, root: import.meta.dirname,
    plugins: [svelte({configFile: false, compilerOptions: {dev: false, experimental: {async}}})],
    resolve: {dedupe: ['svelte']},
    build: {outDir: async ? 'async' : 'normal', minify: false, lib: {entry: `${import.meta.dirname}/entry.js`, formats: ['es'], fileName: () => 'probe.js'}}
  });
}
