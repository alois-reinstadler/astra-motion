import { build } from 'vite';
import { svelte } from '@sveltejs/vite-plugin-svelte';
const replacement = `export function createPresenceBoxes() {
  const observed = new WeakMap<HTMLElement, PresenceBox>();
  const pending = new Map<HTMLElement, PresenceBox>();
  const captured = new WeakMap<HTMLElement, {owner:symbol;box:PresenceBox}>();
  const promote = () => { for(const [node,box] of pending) observed.set(node,box); pending.clear(); };
  const stage = (node:HTMLElement,box:PresenceBox) => {
    if(!observed.has(node)) observed.set(node,box);
    else {pending.set(node,box); frame.postRender(promote);}
  };
  return {
    get(node:HTMLElement) {const origin=captured.get(node);return origin && origin.owner===currentPresenceSnapshot()?origin.box:observed.get(node);},
    observe(node:HTMLElement) {stage(node,measurePresenceBox(node));},
    capture(node:HTMLElement) {
      const owner=currentPresenceSnapshot();
      if(owner && captured.get(node)?.owner===owner)return;
      const box=measurePresenceBox(node);
      if(owner) {observed.set(node,box);captured.set(node,{owner,box});}
      else stage(node,box);
    }
  };
}
`;
for(const variant of ['control','committed','committed-seeded','seed-only']) {
 await build({configFile:false,root:import.meta.dirname,define:{'process.env.NODE_ENV':JSON.stringify('production')},
  plugins:[svelte({configFile:false,compilerOptions:{dev:false}}),{
   name:'diagnostic-immutable-presence',enforce:'pre',
   transform(code,id) {
    if(variant==='control')return;
    if((variant==='committed-seeded'||variant==='seed-only') && id.endsWith('/src/lib/motion/layout.ts')) {
      const marker='projection.willUpdate();\n\t\tprojection.isPresent = isPresent;';
      if(!code.includes(marker))throw new Error('Seed source drift');
      return code.replace(marker,'seedCachedSnapshots([participant]);\n\t\t'+marker);
    }
    if(variant==='seed-only'||!id.endsWith('/src/lib/motion/presence-measure.ts'))return;
    const start=code.indexOf('export function createPresenceBoxes()');
    const end=code.indexOf('export type PresenceBoxes',start);
    if(start<0||end<0)throw new Error('Diagnostic source drift');
    return `import {frame} from 'motion-dom';\n`+code.slice(0,start)+replacement+code.slice(end);
   }
  }],
  resolve:{dedupe:['svelte','motion-dom','motion-utils']},
  build:{outDir:variant,minify:false,lib:{entry:`${import.meta.dirname}/committed-entry.js`,formats:['es'],fileName:()=> 'probe.js'}}
 });
}
