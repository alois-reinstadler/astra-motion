import { chromium } from 'playwright';
import {readFile,writeFile} from 'node:fs/promises';
const browser=await chromium.launch({executablePath:'/usr/bin/google-chrome',args:['--no-sandbox'],headless:true});
const results=[];
try{
for(const variant of ['seed-only']) {
 const source=await readFile(`${import.meta.dirname}/${variant}/probe.js`,'utf8');
 for(const scenario of ['ordinary','interrupted','await','await-remove']) {
  const page=await browser.newPage();const errors=[];page.on('pageerror',e=>errors.push(e.message));
  await page.setContent('<style>body{margin:0}#app{padding:20px}.grid{position:relative;display:grid;width:600px;gap:4px}.cell{box-sizing:border-box;height:24px;font:12px/24px sans-serif}</style><div id="app"></div>');
  await page.addScriptTag({content:source,type:'module'});await page.waitForFunction(()=>window.app!==undefined);await page.waitForTimeout(500);
  const initial=await page.evaluate(()=>({html:document.getElementById('app').innerHTML.slice(0,1200),count:document.querySelectorAll('[data-cell]').length}));
  if(!initial.count){results.push({variant,scenario,initial,errors});await page.close();continue;}
  const record=await page.evaluate(async scenario=>{
   const sleep=ms=>new Promise(r=>setTimeout(r,ms));const find=id=>document.querySelector(`[data-cell="${id}"]`);
   const rect=node=>{const {x,y,width,height}=node.getBoundingClientRect();return{x,y,width,height}};
   const distance=(a,b)=>Math.max(...Object.keys(a).map(k=>Math.abs(a[k]-b[k])));
   if(scenario==='interrupted'){window.app.reverse();await sleep(90);}
   const outgoingBefore=new Map([0,5].map(id=>[id,rect(find(id))]));const survivorBefore=rect(find(1));
   const samples=[];let firstPaint;
   const observer=new MutationObserver(()=>{
    for(const id of [0,5]) {const node=find(id);if(node&&getComputedStyle(node).position==='absolute'&&!samples.some(x=>x.id===id))samples.push({id,error:distance(outgoingBefore.get(id),rect(node)),before:outgoingBefore.get(id),after:rect(node)});}
   });observer.observe(document.body,{attributes:true,childList:true,subtree:true});
   if(scenario.startsWith('await'))window.app.resolveAwait();else window.app.request();
   requestAnimationFrame(()=>{firstPaint=rect(find(1));});
   if(scenario==='await-remove'){await sleep(90);outgoingBefore.clear();[0,5].forEach(id=>outgoingBefore.set(id,rect(find(id))));window.app.request();}
   await sleep(90);const mid=rect(find(1));await sleep(760);const final=rect(find(1));observer.disconnect();
   return{samples,survivorBefore,firstPaint,mid,final,removed:!find(0)&&!find(5),order:[...document.querySelectorAll('[data-cell]')].map(n=>+n.dataset.cell)};
  },scenario);
  results.push({variant,scenario,...record,errors});await page.evaluate(()=>window.cleanup());await page.close();
 }
}
}finally{await browser.close();}
await writeFile(`${import.meta.dirname}/seed-only-results.json`,JSON.stringify(results,null,2));
console.log(JSON.stringify(results.map(({variant,scenario,samples,survivorBefore,firstPaint,mid,final,removed,errors,initial})=>({variant,scenario,error:samples?.map(x=>x.error),survivorBefore,firstPaint,mid,final,removed,errors,initial})),null,2));
