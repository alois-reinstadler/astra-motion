import { mount, unmount, tick, flushSync } from 'svelte';
import Fixture from './WriteFixture.svelte';
window.app = mount(Fixture, {target: document.getElementById('app')});
window.tick = tick;
window.flushSync = flushSync;
window.cleanup = () => unmount(window.app);
