<script>
  import { untrack } from 'svelte';
  let { items } = $props();
  function sample(kind) {
    const grid = document.querySelector('[data-grid]');
    const cell = document.querySelector('[data-cell="0"]');
    if (!grid || !cell) return;
    window.records.push({kind, columns: getComputedStyle(grid).gridTemplateColumns, width: cell.getBoundingClientRect().width, top: cell.getBoundingClientRect().top, order: [...grid.querySelectorAll('[data-cell]')].map(node => node.dataset.cell)});
  }
  $effect.pre(() => { void items; untrack(() => sample('identity')); });
  $effect.pre(() => { void items.length; untrack(() => sample('length')); });
  $effect.pre(() => { void items.map(x => x); untrack(() => sample('deep')); });
</script>
{#each items as id (id)}
  <div data-cell={id} style="height:20px">{id}</div>
{/each}
