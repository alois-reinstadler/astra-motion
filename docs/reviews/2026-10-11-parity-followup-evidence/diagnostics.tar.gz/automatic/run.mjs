import { chromium } from 'playwright';
import { readFile, writeFile } from 'node:fs/promises';
const browser = await chromium.launch({executablePath: '/usr/bin/google-chrome', args: ['--no-sandbox'], headless: true});
const results = [];
try {
  for (const mode of ['normal', 'async']) {
    const source = await readFile(`${import.meta.dirname}/${mode}/probe.js`, 'utf8');
    for (const operation of ['combined', 'siblingCombined', 'reverse', 'splice', 'sibling', 'await']) {
      const page = await browser.newPage();
      const errors=[]; page.on('pageerror', e=>errors.push(e.message));
      await page.setContent('<div id="app"></div>');
      await page.addScriptTag({content: source, type: 'module'});
      await page.waitForFunction(() => window.actions !== undefined);
      await page.evaluate(async () => { await window.tick(); await new Promise(r=>requestAnimationFrame(r)); window.records=[]; });
      const measured = await page.evaluate(async (operation) => {
        const before = document.querySelector('[data-cell="0"]').getBoundingClientRect();
        window.actions[operation]();
        await window.tick(); await new Promise(r=>requestAnimationFrame(r)); await window.tick();
        const after = document.querySelector('[data-cell="0"]')?.getBoundingClientRect();
        return {before:{width:before.width,top:before.top},after:after?{width:after.width,top:after.top}:null,records:window.records};
      }, operation);
      results.push({mode,operation,...measured,errors});
      await page.evaluate(() => window.cleanup()); await page.close();
    }
  }
} finally {await browser.close();}
await writeFile(`${import.meta.dirname}/results.json`,JSON.stringify(results,null,2));
console.log(JSON.stringify(results,null,2));
