import { mount, unmount, tick } from 'svelte';
import App from './App.svelte';
window.records = [];
window.app = mount(App, { target: document.getElementById('app') });
window.tick = tick;
window.cleanup = () => unmount(window.app);
