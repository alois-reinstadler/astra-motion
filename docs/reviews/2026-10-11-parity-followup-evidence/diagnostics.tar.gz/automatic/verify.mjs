import {readFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
const ordering=JSON.parse(await readFile(new URL('results.json',import.meta.url)));
let checks=0;
for(const mode of ['normal','async']){
 const row=op=>ordering.find(x=>x.mode===mode&&x.operation===op);
 assert.equal(row('siblingCombined').before.top,38);checks++;
 assert(row('siblingCombined').records.every(x=>x.top===108));checks++;
 assert.deepEqual(row('reverse').records.map(x=>x.kind),['deep']);checks++;
 for(const op of ['sibling','await']){assert.equal(row(op).after.top-row(op).before.top,70);assert.equal(row(op).records.length,0);checks+=2;}
}
assert.equal(ordering.find(x=>x.mode==='async'&&x.operation==='splice').records.length,0);checks++;
const motion=[...JSON.parse(await readFile(new URL('committed-results.json',import.meta.url))),...JSON.parse(await readFile(new URL('seed-only-results.json',import.meta.url)))];
for(const variant of ['control','committed','committed-seeded','seed-only']){
 for(const scenario of ['ordinary','interrupted']){
  const row=motion.find(x=>x.variant===variant&&x.scenario===scenario);
  const error=Math.max(...row.samples.map(x=>x.error));
  if(variant.includes('seed'))assert(error<=0.75,`${variant} ${scenario}: ${error}`);
  else assert(error>60,`${variant} ${scenario}: negative control ${error}`);
  assert.equal(row.removed,true);assert.deepEqual(row.errors,[]);
  const low=Math.min(row.survivorBefore.x,row.final.x),high=Math.max(row.survivorBefore.x,row.final.x);
  assert(row.mid.x>low+1&&row.mid.x<high-1,`${variant} ${scenario}: no intermediate motion`);
  checks+=4;
 }
}
console.log(`${checks} meaningful geometry and ordering assertions passed; unsupported controls intentionally retained.`);
