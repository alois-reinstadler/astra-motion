<script lang="ts">
import { createPresenceScope, providePresenceScope, usePresence } from '/home/node/.t3/worktrees/astra-motion/t3code-10ab3c8f/src/lib/motion/presence-context.svelte.ts';
const scope = createPresenceScope({isPresent:true, initial:undefined, custom:0}, () => {});
providePresenceScope(scope);
const presence = usePresence();
let effects = 0;
$effect(() => { void presence.isPresent; effects++; });
export function changeCustom() { scope.update(true, 1); }
export function readEffects() { return effects; }
</script>
