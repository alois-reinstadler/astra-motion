import { writeFile, mkdir } from 'node:fs/promises';
import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { build } from '/home/node/.t3/worktrees/astra-motion/t3code-10ab3c8f/node_modules/vite/dist/node/index.js';
import { chromium } from '/home/node/.t3/worktrees/astra-motion/t3code-10ab3c8f/node_modules/playwright/index.mjs';
const repo = '/home/node/.t3/worktrees/astra-motion/t3code-10ab3c8f';
const root = '/tmp/astra-presence-contract';
await writeFile(root + '/index.html', '<div id="root"></div><script type="module" src="/main.js"></script>');
await writeFile(root + '/main.js', `
import React, { useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { flushSync } from 'react-dom';
import { AnimatePresence, usePresence } from 'framer-motion';
const captured = [];
window.completions = 0;
function Child() {
 const [present, remove] = usePresence();
 useEffect(() => { if (!present) captured.push(remove); }, [present, remove]);
 window.initialCallback = present ? remove : window.initialCallback;
 return React.createElement('div', { id:'child' }, String(present));
}
function App() {
 const [present, set] = useState(true);
 window.setPresent = next => flushSync(() => set(next));
 return React.createElement(AnimatePresence, {onExitComplete:()=>window.completions++}, present ? React.createElement(Child, {key:'same'}) : null);
}
window.callbacks = captured;
createRoot(document.getElementById('root')).render(React.createElement(App));
`);
await build({ root, configFile:false, resolve:{alias:{react:repo + '/experiments/staged-rendering/node_modules/react','react-dom':repo + '/experiments/staged-rendering/node_modules/react-dom','framer-motion':repo+'/node_modules/framer-motion'}}, build:{outDir:root+'/dist',minify:false}, logLevel:'warn' });
const server=createServer(async(req,res)=>{try { const path = new URL(req.url,'http://local').pathname; const file = path==='/' ? '/index.html' : path; const content=await readFile(root+'/dist'+file); res.setHeader('Content-Type',file.endsWith('.js')?'application/javascript':'text/html'); res.end(content); } catch {res.statusCode=404;res.end();}});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const browser=await chromium.launch({headless:true});
try {
 const page=await browser.newPage();
 const errors=[];page.on('pageerror',error=>errors.push(error.message));
 await page.goto('http://127.0.0.1:'+server.address().port);
 await page.waitForFunction(()=>window.setPresent && document.getElementById('child'));
 const initial=await page.evaluate(()=>({present:document.getElementById('child').textContent,callbackType:typeof window.initialCallback}));
 await page.evaluate(()=>window.setPresent(false));
 await page.waitForFunction(()=>window.callbacks.length>=1);
 await page.evaluate(()=>{window.oldRemove=window.callbacks.at(-1);window.setPresent(true)});
 await page.waitForFunction(()=>document.getElementById('child')?.textContent==='true');
 await page.evaluate(()=>window.setPresent(false));
 await page.waitForFunction(()=>window.callbacks.length>=2);
 const before=await page.evaluate(()=>({connected:!!document.getElementById('child'),completions:window.completions,sameCallback:window.oldRemove===window.callbacks.at(-1)}));
 await page.evaluate(()=>window.oldRemove());
 await page.waitForFunction(()=>!document.getElementById('child'));
 const after=await page.evaluate(()=>({connected:!!document.getElementById('child'),completions:window.completions}));
 console.log(JSON.stringify({version:'13.4.4',initial,before,after,errors}));
 await page.close();
} finally { await browser.close(); await new Promise(resolve=>server.close(resolve)); }
