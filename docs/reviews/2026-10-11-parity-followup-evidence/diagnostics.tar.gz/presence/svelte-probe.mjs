import { writeFile, readFile } from 'node:fs/promises';
import { createServer } from 'node:http';
import { build } from '/home/node/.t3/worktrees/astra-motion/t3code-10ab3c8f/node_modules/vite/dist/node/index.js';
import { svelte } from '/home/node/.t3/worktrees/astra-motion/t3code-10ab3c8f/node_modules/@sveltejs/vite-plugin-svelte/src/index.js';
import { chromium } from '/home/node/.t3/worktrees/astra-motion/t3code-10ab3c8f/node_modules/playwright/index.mjs';
const repo = '/home/node/.t3/worktrees/astra-motion/t3code-10ab3c8f';
const root = '/tmp/astra-presence-contract';
await writeFile(root + '/main.js', `import {mount,flushSync} from 'svelte'; import Fixture from '${repo}/src/lib/motion-lab/review-probes/PresenceStaleExitFixture.svelte'; const component=mount(Fixture,{target:document.getElementById('root'),props:{variant:'destructured'}}); window.toggle=()=>flushSync(()=>component.toggle()); window.completions=()=>component.completions();`);
const original = `get safeToRemove() {\n\t\t\tconst generation = scope?.snapshot.generation;\n\t\t\treturn () => {\n\t\t\t\tif (generation !== undefined) registration?.complete(generation);\n\t\t\t};\n\t\t}`;
const replacement = `safeToRemove: () => { const generation = scope?.snapshot.generation; if (generation !== undefined) registration?.complete(generation); }`;
const results=[];
const browser=await chromium.launch({headless:true});
try {
 for (const stable of [false,true]) {
  const outDir=root+'/svelte-'+stable;
  const replace={name:'isolated-public-callback-probe',enforce:'pre',transform(source,id){if(stable&&id.endsWith('/presence-context.svelte.ts')){if(!source.includes(original))throw new Error('Patch mismatch');return {code:source.replace(original,replacement),map:null};}}};
  await build({root,configFile:false,plugins:[replace,svelte({configFile:false,compilerOptions:{dev:false,runes:true}})],resolve:{dedupe:['svelte','motion-dom','motion-utils']},build:{outDir,minify:false},logLevel:'error'});
  const server=createServer(async(req,res)=>{try{const path=new URL(req.url,'http://local').pathname;const file=path==='/'?'/index.html':path;res.setHeader('Content-Type',file.endsWith('.js')?'application/javascript':'text/html');res.end(await readFile(outDir+file));}catch{res.statusCode=404;res.end();}});
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  const page=await browser.newPage();const errors=[];page.on('pageerror',error=>errors.push(error.message));
  try {
   await page.goto('http://127.0.0.1:'+server.address().port);
   await page.waitForFunction(()=>window.toggle && document.querySelector('[data-testid="stale-exit-child"]'));
   await page.evaluate(()=>window.toggle());
   await page.waitForFunction(()=>document.querySelector('[data-testid="called"]')?.textContent==='true');
   await page.waitForTimeout(300);
   const outcome=await page.evaluate(()=>({connected:!!document.querySelector('[data-testid="stale-exit-child"]'),completions:window.completions()}));
   results.push({stable,...outcome,errors});
  } finally {await page.close();await new Promise(resolve=>server.close(resolve));}
 }
 console.log(JSON.stringify(results));
} finally {await browser.close();}
