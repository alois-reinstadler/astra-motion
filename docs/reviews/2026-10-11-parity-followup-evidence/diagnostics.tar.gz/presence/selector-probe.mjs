import { writeFile, readFile } from 'node:fs/promises';
import { createServer } from 'node:http';
import { build } from '/home/node/.t3/worktrees/astra-motion/t3code-10ab3c8f/node_modules/vite/dist/node/index.js';
import { svelte } from '/home/node/.t3/worktrees/astra-motion/t3code-10ab3c8f/node_modules/@sveltejs/vite-plugin-svelte/src/index.js';
import { chromium } from '/home/node/.t3/worktrees/astra-motion/t3code-10ab3c8f/node_modules/playwright/index.mjs';
const repo = '/home/node/.t3/worktrees/astra-motion/t3code-10ab3c8f';
const root = '/tmp/astra-presence-contract';
await writeFile(root + '/main.js', `import {mount,flushSync} from 'svelte'; import Fixture from '/tmp/astra-presence-contract/PresenceSelectorFixture.svelte'; const component=mount(Fixture,{target:document.getElementById('root')}); window.changeCustom=()=>flushSync(()=>component.changeCustom()); window.readEffects=()=>component.readEffects();`);
const original = `get safeToRemove() {\n\t\t\tconst generation = scope?.snapshot.generation;\n\t\t\treturn () => {\n\t\t\t\tif (generation !== undefined) registration?.complete(generation);\n\t\t\t};\n\t\t}`;
const replacement = `safeToRemove: () => { const generation = scope?.snapshot.generation; if (generation !== undefined) registration?.complete(generation); }`;
const results=[];
const browser=await chromium.launch({headless:true});
try {
 for (const stable of [false,true]) {
  const outDir=root+'/svelte-'+stable;
  const replace={name:'isolated-public-callback-probe',enforce:'pre',transform(source,id){if(stable&&id.endsWith('/presence-context.svelte.ts')){if(!source.includes(original))throw new Error('Patch mismatch');return {code:source.replace(original,replacement).replace('if (registration) onDestroy(registration.unregister);', 'if (registration) onDestroy(registration.unregister); const isPresent = $derived(scope?.snapshot.isPresent ?? true);').replace('return scope?.snapshot.isPresent ?? true;', 'return isPresent;'),map:null};}}};
  await build({root,configFile:false,plugins:[replace,svelte({configFile:false,compilerOptions:{dev:false,runes:true}})],resolve:{dedupe:['svelte','motion-dom','motion-utils']},build:{outDir,minify:false},logLevel:'error'});
  const server=createServer(async(req,res)=>{try{const path=new URL(req.url,'http://local').pathname;const file=path==='/'?'/index.html':path;res.setHeader('Content-Type',file.endsWith('.js')?'application/javascript':'text/html');res.end(await readFile(outDir+file));}catch{res.statusCode=404;res.end();}});
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  const page=await browser.newPage();const errors=[];page.on('pageerror',error=>errors.push(error.message));
  try {
   await page.goto('http://127.0.0.1:'+server.address().port);
   await page.waitForFunction(()=>window.changeCustom && window.readEffects() > 0);
   const before=await page.evaluate(()=>window.readEffects()); await page.evaluate(()=>window.changeCustom());
   
   await page.waitForTimeout(30);
   const outcome=await page.evaluate(()=>({effects:window.readEffects()}));
   results.push({stable,before,...outcome,errors});
  } finally {await page.close();await new Promise(resolve=>server.close(resolve));}
 }
 console.log(JSON.stringify(results));
} finally {await browser.close();}
